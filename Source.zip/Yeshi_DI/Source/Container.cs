using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Yeshi_DI.DUnits;
using Yeshi_DI.Injection;

namespace Yeshi_DI
{
    public class Container : IDisposable
    {
        public Container(Container parent = null)
        {
            _parent = parent;
        }

        private readonly Container _parent;
        
        private readonly Injector _injector = new();
        
        private readonly Stack<DUnit> _requests = new();
        private readonly Dictionary<(string, Type), DUnit> _units = new();
        
        private readonly HashSet<(string, Type)> _recentKeys = new();

        private bool _isInitialized;

        public void Init()
        {
            if (_isInitialized)
                throw new InvalidOperationException($"[Yeshi DI] Container {this} is already initialized.");

            while (_requests.Count > 0)
            {
                var unit = _requests.Pop();
                var key = (unit.Tag, unit.RegisteredType);

                if (unit.ResolveType == ResolveType.Singleton)
                    if (!unit.IsLazy)
                        unit.CreateInstance(this);

                _units.Add(key, unit);
                Debug.Log($"[Yeshi DI] Service registered with registered type: {unit.RegisteredType} and original type: {unit.OriginalType}.");
            }

            foreach (var u in _units.Where(u => u.Value.Instance != null))
                _injector.Inject(u.Value.Instance, this);
        }

        public DUnitBuilder Register<T>()
        {
            var type = typeof(T);
            var request = type.IsAbstract
                ? new DUnitBuilder(type)
                : new DUnitBuilder(type, type);

            _requests.Push(request);
            return request;
        }

        public DUnitBuilder Register(Type type)
        {
            var request = type.IsAbstract
                ? new DUnitBuilder(type)
                : new DUnitBuilder(type, type);

            _requests.Push(request);
            return request;
        }

        public DUnitBuilder RegisterSingleton<T>() => Register<T>().Singleton();

        public DUnitBuilder RegisterSingleton(Type type) => Register(type).Singleton();

        public DUnitBuilder RegisterTransient<T>() => Register<T>().Transient();

        public DUnitBuilder RegisterTransient(Type type) => Register(type).Transient();

        public DUnitBuilder RegisterInstance<T>(object instance) => Register<T>().Singleton().FromInstance(instance);

        public DUnitBuilder RegisterInstance(Type type, object instance) =>
            Register(type).Singleton().FromInstance(instance);

        public T Resolve<T>(string tag = null)
        {
            var type = typeof(T);
            var key = (tag, type);

            if (!_recentKeys.Add(key))
                throw new Exception($"[Yeshi DI] Recursive method invoked for tag: {tag} and type: {key.type}.");

            try
            {
                if (_units.TryGetValue(key, out var unit))
                    return unit.GetInstance<T>(this);

                if (_parent != null)
                    return _parent.Resolve<T>(tag);
            }
            finally
            {
                _recentKeys.Remove(key);
            }

            throw new Exception($"[Yeshi DI] Unit with tag: {tag} and type: {key.type} not found.");
        }

        public object Resolve(Type type, string tag = null)
        {
            var key = (tag, type);

            if (!_recentKeys.Add(key))
                throw new Exception($"[Yeshi DI] Recursive method invoked for tag: {tag} and type: {key.type}.");

            try
            {
                if (_units.TryGetValue(key, out var unit))
                    return unit.GetInstance(this);

                if (_parent != null)
                    return _parent.Resolve(type, tag);
            }
            finally
            {
                _recentKeys.Remove(key);
            }
            
            throw new Exception($"[Yeshi DI] Unit with tag: {tag} and type: {key.type} not found.");
        }

        public void Dispose()
        {
            foreach (var u in _units)
                if (u.Value.Instance is IDisposable disposable)
                    disposable.Dispose();

            _units.Clear();
            _requests.Clear();
            _isInitialized = false;
        }
    }
}