using System;

namespace Yeshi_DI.DUnits
{
    public class DUnit
    {
        public object Instance { get; set; }
        public Type RegisteredType { get; set; }
        public Type OriginalType { get; set; }
        public InitType InitType { get; set; }
        public ResolveType ResolveType { get; set; }
        public Func<Container, object> Factory { get; set; }
        public bool IsLazy { get; set; }
        public string Tag { get; set; }
    }
}