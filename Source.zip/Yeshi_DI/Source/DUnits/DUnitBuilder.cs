using System;

namespace Yeshi_DI.DUnits
{
    public class DUnitBuilder : DUnit
    {
        public DUnitBuilder(Type registeredType, Type originalType = null)
        {
            RegisteredType = registeredType;
            OriginalType = originalType;
        }

        public DUnitBuilder Prototype(DUnit prototype)
        {
            ResolveType = prototype.ResolveType;
            InitType = prototype.InitType;
            Factory = prototype.Factory;
            IsLazy = prototype.IsLazy;
            Tag = prototype.Tag;
            return this;
        }

        public DUnitBuilder As<T>() where T : new()
        {
            var type = typeof(T);

            OriginalType = type;
            return this;
        }

        public DUnitBuilder NonLazy()
        {
            IsLazy = false;
            return this;
        }

        public DUnitBuilder Lazy()
        {
            IsLazy = true;
            return this;
        }

        public DUnitBuilder FromCtor()
        {
            InitType = InitType.FromConstructor;
            return this;
        }

        public DUnitBuilder FromFactory(Func<Container, object> factory)
        {
            InitType = InitType.FromFactory;
            Factory = factory;
            return this;
        }

        public DUnitBuilder FromInstance<T>(T instance) where T : new()
        {
            InitType = InitType.FromInstance;
            Instance = instance;
            return this;
        }

        public DUnitBuilder Singleton()
        {
            ResolveType = ResolveType.Singleton;
            return this;
        }

        public DUnitBuilder Transient()
        {
            ResolveType = ResolveType.Transient;
            return this;
        }

        public DUnitBuilder WithTag(string tag)
        {
            Tag = tag;
            return this;
        }
    }
}