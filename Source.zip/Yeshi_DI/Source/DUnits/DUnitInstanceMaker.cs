using System;

namespace Yeshi_DI.DUnits
{
    public static class DUnitInstanceMaker
    {
        public static T GetInstance<T>(this DUnit unit, Container container)
        {
            switch (unit.ResolveType)
            {
                case ResolveType.Singleton when unit.Instance == null:
                case ResolveType.Transient:
                    unit.CreateInstance(container);
                    break;
                case ResolveType.Singleton:
                    break;
                default:
                    throw new Exception($"[Yeshi DI] Unknown resolve type: {unit.ResolveType}.");
            }

            return (T)unit.Instance;
        }
        
        public static object GetInstance(this DUnit unit, Container container)
        {
            switch (unit.ResolveType)
            {
                case ResolveType.Singleton when unit.Instance == null:
                case ResolveType.Transient:
                    unit.CreateInstance(container);
                    break;
                case ResolveType.Singleton:
                    break;
                default:
                    throw new Exception($"[Yeshi DI] Unknown resolve type: {unit.ResolveType}.");
            }

            return unit.Instance;
        }

        public static void CreateInstance(this DUnit unit, Container container)
        {
            switch (unit.InitType)
            {
                case InitType.FromConstructor:
                    unit.CreateInstanceViaCtor();
                    break;
                case InitType.FromFactory:
                    unit.CreateInstanceViaFactory(container);
                    break;
                case InitType.FromInstance:
                    break;
                default:
                    throw new Exception($"[Yeshi DI] Unknown initialization type: {unit.InitType}.");
            }
        }

        private static void CreateInstanceViaCtor(this DUnit unit)
        {
            if (unit.InitType != InitType.FromConstructor)
                throw new Exception($"[Yeshi DI] DUnit have different initialize type: {unit.InitType}.");

            unit.Instance = Activator.CreateInstance(unit.OriginalType);
        }

        private static void CreateInstanceViaFactory(this DUnit unit, Container container)
        {
            if (unit.InitType != InitType.FromFactory)
                throw new Exception($"[Yeshi DI] DUnit have different initialize type: {unit.InitType}.");

            if (unit.Factory != null)
                unit.Instance = unit.Factory(container);
            else
                throw new Exception(
                    $"[Yeshi DI] Factory not initialized for unit of registered type: {unit.RegisteredType}.");
        }
    }
}