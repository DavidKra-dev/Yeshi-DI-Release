namespace Yeshi_DI.DUnits
{
    public enum InitType
    {
        FromConstructor,
        FromFactory,
        FromInstance
    }
}