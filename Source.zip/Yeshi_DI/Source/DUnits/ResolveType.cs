namespace Yeshi_DI.DUnits
{
    public enum ResolveType
    {
        Singleton,
        Transient
    }
}