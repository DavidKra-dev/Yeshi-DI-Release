using System.Linq;

namespace Yeshi_DI.Injection
{
    public class Injector
    {
        public void Inject(object target, Container container)
        {
            var type = target.GetType();
            var method = type.GetMethod("Inject");

            if (method == null) return;
            var parameters = method.GetParameters();

            var parametersList = parameters.Select(p => container.Resolve(p.ParameterType));

            method.Invoke(target, parametersList.ToArray());
        }
    }

    // [AttributeUsage(AttributeTargets.All)]
    // public class Inject : Attribute
    // {
    // }
}