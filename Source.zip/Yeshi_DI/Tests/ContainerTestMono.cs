using UnityEngine;

namespace Yeshi_DI.Tests
{
    public class ContainerTestMono : MonoBehaviour
    {
        private readonly Container _container = new();

        private void Awake()
        {
            _container.RegisterSingleton<IInjectionTest>().As<InjectionTest>();
            _container.RegisterSingleton<IInjectionUnit>().As<InjectionUnit>();
            _container.RegisterSingleton<InjectionUnit_2>();

            _container.Init();
        }

        private void Start()
        {
            _container.Resolve<IInjectionTest>().DebugTest();
        }
    }
}