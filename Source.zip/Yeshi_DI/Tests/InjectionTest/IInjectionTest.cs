namespace Yeshi_DI.Tests
{
    public interface IInjectionTest
    {
        void DebugTest();
    }
}