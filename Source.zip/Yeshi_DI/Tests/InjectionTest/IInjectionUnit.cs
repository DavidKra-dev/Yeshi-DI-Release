namespace Yeshi_DI.Tests
{
    public interface IInjectionUnit
    {
        void DebugTest();
    }
}