namespace Yeshi_DI.Tests
{
    public class InjectionTest : IInjectionTest
    {
        private IInjectionUnit _test;
        private IInjectionUnit _test2;

        public void Inject(IInjectionUnit test, InjectionUnit_2 test2)
        {
            _test = test;
            _test2 = test2;
        }

        public void DebugTest()
        {
            _test.DebugTest();
            _test2.DebugTest();
        }
    }
}