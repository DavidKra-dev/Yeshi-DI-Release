using UnityEngine;

namespace Yeshi_DI.Tests
{
    public class InjectionUnit : IInjectionUnit
    {
        public void DebugTest()
        {
            Debug.Log("Injection working!!!");
        }
    }
}